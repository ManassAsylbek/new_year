Audio

let soundButton = document.querySelector(".soundbutton"),
    audio = document.querySelector(".audio");

soundButton.addEventListener("click", (e) => {
    soundButton.classList.toggle("paused");
    audio.paused ? audio.play() : audio.pause();
});

window.onfocus = function () {
    soundButton.classList.contains("paused") ? audio.pause() : audio.play();
};
window.onblur = function () {
    audio.pause();
};
